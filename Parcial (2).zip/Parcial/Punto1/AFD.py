import re

def afd(exp):
    patterns = {
        r"^\+$": "SUMA",
        r"^\+\+$": "INCREMENTO",
        r"^-?\d+$": "NÚMERO ENTERO",
        r"^-?\d+\.\d+$": "NÚMERO REAL"
    }

    for pattern, token in patterns.items():
        if re.match(pattern, exp):
            return token
    return "NO ACEPTADO"

# Ejemplo de uso
expresion = input("Expresiòn a evaluar: ")
print(afd(expresion))
