#include <stdio.h>
#include <string.h>

#define MAX_LINEA 1000

int contar_palabra(FILE *archivo, const char *clave) {
    char linea[MAX_LINEA];
    int contador = 0;
    size_t largo_clave = strlen(clave);

    // Leer línea por línea del archivo
    while (fgets(linea, MAX_LINEA, archivo) != NULL) {
        char *posicion = linea;
        // Buscar la palabra clave en cada línea
        while ((posicion = strstr(posicion, clave)) != NULL) {
            // Aumenta el contador cuando encuentre la clave
            contador++;
            // Avanza en la línea para evitar contar la misma coincidencia
            posicion += largo_clave;
        }
    }
    return contador;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Uso: %s <archivo> <palabra_clave>\n", argv[0]);
        return 1;
    }

    FILE *archivo = fopen(argv[1], "r");
    if (archivo == NULL) {
        printf("Error: No se pudo abrir el archivo %s\n", argv[1]);
        return 1;
    }

    const char *clave = argv[2];
    int coincidencias = contar_palabra(archivo, clave);

    printf("%s se repite %d veces en el texto.\n", clave, coincidencias);

    fclose(archivo);
    return 0;
}
